#!/usr/bin/env python3

def hello(): 
    print('hello world')

def main(): 
    # does stuff
    hello()

if __name__ == '__main__':
    main()
