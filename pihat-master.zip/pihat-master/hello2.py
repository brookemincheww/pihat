#!/usr/bin/env python3

from hello import hello 

if __name__ == '__main__'
    hello()
